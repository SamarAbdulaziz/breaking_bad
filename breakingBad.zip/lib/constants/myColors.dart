import 'package:flutter/material.dart';

class MyColors{
   static const Color myYellow=Color(0xffFFc107);
   static const Color myGrey=Color(0xff343A40);
   static const Color myWhite=Color(0xffE1E8EB);

}