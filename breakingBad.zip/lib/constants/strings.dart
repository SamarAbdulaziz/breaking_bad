final baseUrl='https://www.breakingbadapi.com/api/';
const charactersScreen='/';
const characterDetailsScreen='character_details';

