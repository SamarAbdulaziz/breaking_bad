package com.example.flutter_breaking_youtube

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
